# 一款情侣情趣甜蜜游戏，使用uniapp开发 #
# 已上架微信小程序可扫码体验 #
![WechatIMG236](https://github.com/user-attachments/assets/05ce7b49-e468-4019-84ce-1637252fe0ea)




## 游戏体验地址 http://xs.144881.com/ ##

+ git clone xxx
  
+ 拉下代码就可直接运行，已经打包好了的纯静态实现

+ ![3641111459](https://github.com/lllbbbmmm/fei/assets/48704531/6301b350-23ce-40f5-84a3-18317ff8d52e) 
+ ![2469315931](https://github.com/lllbbbmmm/fei/assets/48704531/63379de0-fbdb-4d3d-8ca5-fb4e3cac55e3) 
+ ![1807826052](https://github.com/lllbbbmmm/fei/assets/48704531/ed7cc3e2-0953-41a6-a2f8-c2e532b962ae) 


+ 需要源码二次开发可联系v gznh777888
